Sources

Paws - https://www.clipartqueen.com/image-files/paw-prints-clipart-dog-paws.gif

Tabby Cat - https://www.pinterest.co.uk/pin/373165519095897567/?lp=true
Russian Blue - https://www.pinterest.co.uk/pin/103934703874940124/
Ragdoll - http://9meow.blogspot.com/2012/06/ragdoll-cute-cats.html
Siamese - http://dompict.com/funny-animals/funny-cat/siamese-cats-95-pictures/47/
Japanese Bobtail - https://www.catbreedselector.com/japanese-bobtail.asp
British Shorthair - http://cat-pictur.blogspot.com/2012/11/british-shorthair-cat-pictures.html
Burmilla - https://www.catbreedselector.com/burmilla.asp
Colorpoint Shorthair - https://www.thehappycatsite.com/colorpoint-shorthair/
Husky - https://inspirationseek.com/siberian-husky-dog-temperament-training-and-pictures/
Labrador - https://www.youtube.com/watch?v=bZy6PzW7jj8
Lhasa Apso - http://www.petpaw.com.au/breeds/lhasa-apso/
Pekingese - https://www.dogslife.com.au/dog-breeds/pekingese
Beagle - http://som-o-yrc.weebly.com/animal/september-15th-2015
Airedale - http://www.dogwallpapers.net/airedale-terrier/picture-of-airedale-terrier-and-his-cup.html
Chihuahua - https://www.youtube.com/watch?v=-F-gzfwA6XA
Dachshund - http://www.fanpop.com/clubs/dachshunds/images/13634801/title

